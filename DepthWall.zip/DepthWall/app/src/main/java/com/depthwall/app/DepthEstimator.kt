package com.depthwall.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max

/**
 * Runs Depth Anything V2 (small) ONCE per wallpaper and returns a grayscale
 * depth map (white = near, black = far). The live wallpaper never runs AI.
 */
object DepthEstimator {

    private fun modelFile(c: Context): File {
        val f = File(c.filesDir, "depth_model.onnx")
        val len = c.assets.openFd("depth.onnx").use { it.length }
        if (!f.exists() || f.length() != len) {
            val tmp = File(c.filesDir, "depth_model.tmp")
            c.assets.open("depth.onnx").use { input ->
                tmp.outputStream().use { input.copyTo(it) }
            }
            tmp.renameTo(f)
        }
        return f
    }

    @Synchronized
    fun estimate(c: Context, src: Bitmap, detailed: Boolean): Bitmap {
        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val session = env.createSession(modelFile(c).absolutePath, opts)
        try {
            val inName = session.inputNames.first()
            val shape = (session.inputInfo[inName]!!.info as TensorInfo).shape
            val fallback = if (detailed) 518 else 392
            val h = if (shape.size == 4 && shape[2] > 0) shape[2].toInt() else fallback
            val w = if (shape.size == 4 && shape[3] > 0) shape[3].toInt() else h

            val scaled = Bitmap.createScaledBitmap(src, w, h, true)
            val px = IntArray(w * h)
            scaled.getPixels(px, 0, w, 0, 0, w, h)

            val buf = ByteBuffer.allocateDirect(4 * 3 * w * h)
                .order(ByteOrder.nativeOrder()).asFloatBuffer()
            val mean = floatArrayOf(0.485f, 0.456f, 0.406f)
            val std = floatArrayOf(0.229f, 0.224f, 0.225f)
            val plane = w * h
            for (i in 0 until plane) {
                val p = px[i]
                val r = ((p shr 16) and 255) / 255f
                val g = ((p shr 8) and 255) / 255f
                val b = (p and 255) / 255f
                buf.put(i, (r - mean[0]) / std[0])
                buf.put(plane + i, (g - mean[1]) / std[1])
                buf.put(2 * plane + i, (b - mean[2]) / std[2])
            }

            val input = OnnxTensor.createTensor(env, buf, longArrayOf(1, 3, h.toLong(), w.toLong()))
            input.use {
                session.run(mapOf(inName to input)).use { res ->
                    val out = res[0] as OnnxTensor
                    val os = out.info.shape
                    val oh = os[os.size - 2].toInt()
                    val ow = os[os.size - 1].toInt()
                    val arr = FloatArray(oh * ow)
                    out.floatBuffer.get(arr)

                    // robust normalisation: ignore the 1% extremes
                    val sorted = arr.copyOf().also { it.sort() }
                    val lo = sorted[(arr.size * 0.01f).toInt()]
                    val hi = sorted[(arr.size * 0.99f).toInt().coerceAtMost(arr.size - 1)]
                    val range = max(hi - lo, 1e-6f)

                    val outPx = IntArray(oh * ow)
                    for (i in arr.indices) {
                        val v = ((arr[i] - lo) / range).coerceIn(0f, 1f)
                        val gr = (v * 255f).toInt()
                        outPx[i] = (0xFF shl 24) or (gr shl 16) or (gr shl 8) or gr
                    }
                    val bmp = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
                    bmp.setPixels(outPx, 0, ow, 0, 0, ow, oh)
                    return bmp
                }
            }
        } finally {
            session.close() // free ~400 MB of RAM right away
        }
    }
}

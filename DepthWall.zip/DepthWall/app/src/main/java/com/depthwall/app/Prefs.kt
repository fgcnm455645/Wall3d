package com.depthwall.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val K_PARALLAX = "parallax"
    const val K_DEPTH = "depth"
    const val K_DETAILED = "detailed"
    const val K_INVERT = "invert"
    const val K_STRENGTH = "strength"
    const val K_SMOOTH = "smooth"
    const val K_FOCUS = "focus"
    const val K_ZOOM = "zoom"
    const val K_ACTIVE = "active"
    const val K_REV = "rev"

    fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("settings", Context.MODE_PRIVATE)
}

/** Snapshot of the settings the renderer needs. */
class Params(
    val parallax: Boolean,
    val depth: Boolean,
    val invert: Boolean,
    val strength: Float,
    val smooth: Float,
    val focus: Float,
    val zoom: Float
) {
    companion object {
        fun read(sp: SharedPreferences) = Params(
            parallax = sp.getBoolean(Prefs.K_PARALLAX, true),
            depth = sp.getBoolean(Prefs.K_DEPTH, true),
            invert = sp.getBoolean(Prefs.K_INVERT, false),
            strength = sp.getFloat(Prefs.K_STRENGTH, 0.6f),
            smooth = sp.getFloat(Prefs.K_SMOOTH, 0.5f),
            focus = sp.getFloat(Prefs.K_FOCUS, 0.5f),
            zoom = sp.getFloat(Prefs.K_ZOOM, 0.3f)
        )
    }
}

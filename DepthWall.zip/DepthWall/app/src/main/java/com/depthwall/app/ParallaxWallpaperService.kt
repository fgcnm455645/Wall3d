package com.depthwall.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.opengl.GLSurfaceView
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.abs

class ParallaxWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ParallaxEngine()

    inner class ParallaxEngine : Engine(), SensorEventListener,
        SharedPreferences.OnSharedPreferenceChangeListener {

        private inner class GLView(ctx: Context) : GLSurfaceView(ctx) {
            override fun getHolder(): SurfaceHolder = surfaceHolder
            fun destroyView() = super.onDetachedFromWindow()
        }

        private var glView: GLView? = null
        private lateinit var renderer: ParallaxRenderer
        private lateinit var sm: SensorManager
        private lateinit var sp: SharedPreferences
        private var visible = false
        private var sensorOn = false
        private var loadedId: String? = null

        // tilt filtering
        private var inited = false
        private var gx = 0f; private var gz = 0f
        private var baseX = 0f; private var baseZ = 0f
        private var lastTx = 0f; private var lastTy = 0f

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            val app = this@ParallaxWallpaperService
            sm = app.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sp = Prefs.sp(app.applicationContext)
            renderer = ParallaxRenderer { glView?.requestRender() }
            renderer.params = Params.read(sp)
            glView = GLView(app).also { v ->
                v.setEGLContextClientVersion(2)
                v.preserveEGLContextOnPause = true
                v.setRenderer(renderer)
                v.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
            }
            sp.registerOnSharedPreferenceChangeListener(this)
            loadActive()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                glView?.onResume()
                loadActive()
                inited = false // re-centre the tilt every time the screen wakes
                startSensor()
                glView?.requestRender()
            } else {
                stopSensor()
                glView?.onPause()
            }
        }

        override fun onDestroy() {
            stopSensor()
            sp.unregisterOnSharedPreferenceChangeListener(this)
            glView?.destroyView()
            glView = null
            super.onDestroy()
        }

        private fun startSensor() {
            if (sensorOn || !renderer.params.parallax) return
            val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
            sensorOn = true
        }

        private fun stopSensor() {
            if (!sensorOn) return
            sm.unregisterListener(this)
            sensorOn = false
        }

        override fun onSensorChanged(e: SensorEvent) {
            val x = e.values[0]
            val z = e.values[2]
            if (!inited) {
                gx = x; gz = z; baseX = x; baseZ = z; inited = true
            }
            gx += (x - gx) * 0.25f
            gz += (z - gz) * 0.25f
            baseX += (gx - baseX) * 0.004f // slow re-centring while you hold the phone
            baseZ += (gz - baseZ) * 0.004f
            var tx = ((gx - baseX) / 3f).coerceIn(-1f, 1f)
            var ty = ((gz - baseZ) / 3f).coerceIn(-1f, 1f)
            if (renderer.params.invert) { tx = -tx; ty = -ty }
            renderer.targetX = tx
            renderer.targetY = ty
            if (abs(tx - lastTx) + abs(ty - lastTy) > 0.002f) {
                lastTx = tx; lastTy = ty
                glView?.requestRender()
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        override fun onSharedPreferenceChanged(prefs: SharedPreferences, key: String?) {
            when (key) {
                Prefs.K_ACTIVE -> loadActive()
                Prefs.K_REV -> { loadedId = null; loadActive() }
                else -> {
                    renderer.params = Params.read(sp)
                    if (visible) {
                        if (key == Prefs.K_PARALLAX) { stopSensor(); startSensor() }
                        glView?.requestRender()
                    }
                }
            }
        }

        private fun loadActive() {
            val c = applicationContext
            val id = sp.getString(Prefs.K_ACTIVE, null)?.takeIf { Store.image(c, it).exists() }
                ?: Store.ids(c).lastOrNull()
            if (id == null) {
                loadedId = null
                renderer.setWallpaper(null, null)
                return
            }
            if (id == loadedId) return
            loadedId = id
            Thread {
                val img = BitmapFactory.decodeFile(Store.image(c, id).absolutePath)
                val df = Store.depth(c, id)
                val dep = if (df.exists()) BitmapFactory.decodeFile(df.absolutePath) else null
                if (loadedId == id) renderer.setWallpaper(img, dep)
            }.start()
        }
    }
}

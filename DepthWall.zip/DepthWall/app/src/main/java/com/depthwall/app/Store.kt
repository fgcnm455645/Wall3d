package com.depthwall.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** Wallpapers live in filesDir/walls/<id>/{image.jpg, depth.png}. */
object Store {
    private const val MAX_SIDE = 2400

    private fun root(c: Context) = File(c.filesDir, "walls").apply { mkdirs() }
    fun image(c: Context, id: String) = File(root(c), "$id/image.jpg")
    fun depth(c: Context, id: String) = File(root(c), "$id/depth.png")

    fun ids(c: Context): List<String> =
        root(c).listFiles()
            ?.filter { it.isDirectory && File(it, "image.jpg").exists() }
            ?.map { it.name }?.sorted() ?: emptyList()

    private fun decode(c: Context, uri: Uri): Bitmap {
        val source = ImageDecoder.createSource(c.contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val side = max(info.size.width, info.size.height)
            if (side > MAX_SIDE) {
                val s = MAX_SIDE.toFloat() / side
                dec.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
            }
        }
    }

    private fun saveDepth(c: Context, id: String, img: Bitmap, detailed: Boolean) {
        val d = DepthEstimator.estimate(c, img, detailed)
        FileOutputStream(depth(c, id)).use { d.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    /** Returns (id, errorMessageOrNull). The image is kept even if depth fails. */
    fun add(c: Context, uri: Uri, detailed: Boolean): Pair<String, String?> {
        val bmp = decode(c, uri)
        val id = System.currentTimeMillis().toString()
        image(c, id).parentFile!!.mkdirs()
        FileOutputStream(image(c, id)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        val err = try {
            saveDepth(c, id, bmp, detailed); null
        } catch (t: Throwable) {
            "Depth failed: ${t.message}"
        }
        return id to err
    }

    fun recalc(c: Context, id: String, detailed: Boolean) {
        val bmp = android.graphics.BitmapFactory.decodeFile(image(c, id).absolutePath)
        saveDepth(c, id, bmp, detailed)
    }

    fun delete(c: Context, id: String) {
        File(root(c), id).deleteRecursively()
    }
}

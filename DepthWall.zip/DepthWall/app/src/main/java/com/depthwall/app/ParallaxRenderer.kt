package com.depthwall.app

import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs

/**
 * Pure-GPU parallax: one fragment shader shifts every pixel by (depth - focus) * tilt.
 * Renders only while the tilt is changing, so it is idle (0% GPU) when the phone is still.
 */
class ParallaxRenderer(private val requestFrame: () -> Unit) : GLSurfaceView.Renderer {

    @Volatile var targetX = 0f
    @Volatile var targetY = 0f
    @Volatile var params: Params = Params(true, true, false, 0.6f, 0.5f, 0.5f, 0.3f)

    private var curX = 0f
    private var curY = 0f

    private val lock = Any()
    private var imgBmp: Bitmap? = null
    private var depthBmp: Bitmap? = null
    private var dirty = false

    private var program = 0
    private val tex = IntArray(2)
    private var hasImage = false
    private var hasDepth = false
    private var imgAspect = 1f
    private var sw = 1
    private var sh = 1

    private var uCover = 0; private var uTilt = 0; private var uAmp = 0
    private var uFocus = 0; private var uUseDepth = 0; private var uImg = 0; private var uDepth = 0
    private var aPos = 0

    private val quad = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
    }

    fun setWallpaper(img: Bitmap?, depth: Bitmap?) {
        synchronized(lock) {
            imgBmp = img
            depthBmp = depth
            dirty = true
        }
        requestFrame()
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        program = buildProgram(VERT, FRAG)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uCover = GLES20.glGetUniformLocation(program, "uCover")
        uTilt = GLES20.glGetUniformLocation(program, "uTilt")
        uAmp = GLES20.glGetUniformLocation(program, "uAmp")
        uFocus = GLES20.glGetUniformLocation(program, "uFocus")
        uUseDepth = GLES20.glGetUniformLocation(program, "uUseDepth")
        uImg = GLES20.glGetUniformLocation(program, "uImg")
        uDepth = GLES20.glGetUniformLocation(program, "uDepth")
        GLES20.glGenTextures(2, tex, 0)
        hasImage = false
        hasDepth = false
        synchronized(lock) { dirty = imgBmp != null } // GL context was lost: re-upload
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        sw = width
        sh = height
        GLES20.glViewport(0, 0, width, height)
    }

    private fun upload(texId: Int, bmp: Bitmap) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
    }

    override fun onDrawFrame(gl: GL10?) {
        synchronized(lock) {
            if (dirty) {
                dirty = false
                val i = imgBmp
                val d = depthBmp
                hasImage = false
                hasDepth = false
                if (i != null && !i.isRecycled) {
                    upload(tex[0], i)
                    imgAspect = i.width.toFloat() / i.height
                    hasImage = true
                    if (d != null && !d.isRecycled) {
                        upload(tex[1], d)
                        hasDepth = true
                    }
                }
            }
        }
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (!hasImage) return

        val p = params
        val tx = if (p.parallax) targetX else 0f
        val ty = if (p.parallax) targetY else 0f
        val k = 0.30f - p.smooth * 0.26f // smoothness 0 -> snappy, 1 -> floaty
        curX += (tx - curX) * k
        curY += (ty - curY) * k
        if (abs(tx - curX) > 0.0008f || abs(ty - curY) > 0.0008f) requestFrame()

        val screenAspect = sw.toFloat() / sh
        var cx = 1f
        var cy = 1f
        if (imgAspect > screenAspect) cx = screenAspect / imgAspect else cy = imgAspect / screenAspect
        val z = 1.04f + p.zoom * 0.26f
        cx /= z
        cy /= z
        val amp = p.strength * (1f - 1f / z) * 0.5f

        GLES20.glUseProgram(program)
        GLES20.glUniform2f(uCover, cx, cy)
        GLES20.glUniform2f(uTilt, curX, curY)
        GLES20.glUniform1f(uAmp, amp)
        GLES20.glUniform1f(uFocus, p.focus)
        GLES20.glUniform1f(uUseDepth, if (p.depth && hasDepth) 1f else 0f)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
        GLES20.glUniform1i(uImg, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[1])
        GLES20.glUniform1i(uDepth, 1)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    private fun buildProgram(vs: String, fs: String): Int {
        fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            return s
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        private const val VERT = """
attribute vec2 aPos;
varying vec2 vUv;
void main() {
    gl_Position = vec4(aPos, 0.0, 1.0);
    vUv = vec2(aPos.x * 0.5 + 0.5, 0.5 - aPos.y * 0.5);
}
"""
        private const val FRAG = """
precision highp float;
varying vec2 vUv;
uniform sampler2D uImg;
uniform sampler2D uDepth;
uniform vec2 uCover;
uniform vec2 uTilt;
uniform float uAmp;
uniform float uFocus;
uniform float uUseDepth;

float dep(vec2 p) { return texture2D(uDepth, clamp(p, 0.0, 1.0)).r; }
float depSmooth(vec2 p) {
    vec2 e = vec2(0.0035);
    return (dep(p) * 2.0 + dep(p + vec2(e.x, 0.0)) + dep(p - vec2(e.x, 0.0))
          + dep(p + vec2(0.0, e.y)) + dep(p - vec2(0.0, e.y))) / 6.0;
}
void main() {
    vec2 base = 0.5 + (vUv - 0.5) * uCover;
    float norm = 1.0 / max(max(uFocus, 1.0 - uFocus), 0.05);
    vec2 off;
    if (uUseDepth > 0.5) {
        float d0 = depSmooth(base);
        vec2 o0 = uTilt * uAmp * (d0 - uFocus) * norm * uCover;
        float d1 = dep(base + o0);
        off = uTilt * uAmp * (d1 - uFocus) * norm * uCover;
    } else {
        off = uTilt * uAmp * uCover;
    }
    gl_FragColor = vec4(texture2D(uImg, clamp(base + off, 0.0, 1.0)).rgb, 1.0);
}
"""
    }
}

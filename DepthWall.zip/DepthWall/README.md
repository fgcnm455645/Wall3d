# DepthWall
Lightweight 3D (depth) parallax live wallpaper.
Depth is computed once when you add an image (Depth Anything V2 Small, Apache-2.0).
The wallpaper only runs a small GPU shader + the accelerometer, no AI at runtime.

## Build (GitHub Actions)
1. Upload this whole folder to a GitHub repo (the model is NOT included; the workflow downloads it).
2. Actions tab -> "Build APK" -> Run workflow.
3. Download the artifact DepthWall-debug -> install the APK.

package com.depthwall.app

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0E0E12)
private val Sheet = Color(0xFF1A1A1F)
private val CardC = Color(0xFF26262C)
private val Accent = Color(0xFFE6E6EA)
private val Dim = Color(0xFF9A9AA3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, onPrimary = Sheet,
                    background = Bg, surface = Sheet, onSurface = Accent
                )
            ) { Root() }
        }
    }
}

private fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()

@Composable
fun Root() {
    val ctx = LocalContext.current
    val sp = remember { Prefs.sp(ctx) }
    val scope = rememberCoroutineScope()

    var ids by remember { mutableStateOf(Store.ids(ctx)) }
    var active by remember {
        mutableStateOf(sp.getString(Prefs.K_ACTIVE, null)?.takeIf { it in ids } ?: ids.lastOrNull())
    }
    var busy by remember { mutableStateOf<String?>(null) }
    var showDepth by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }

    var parallax by remember { mutableStateOf(sp.getBoolean(Prefs.K_PARALLAX, true)) }
    var depthOn by remember { mutableStateOf(sp.getBoolean(Prefs.K_DEPTH, true)) }
    var detailed by remember { mutableStateOf(sp.getBoolean(Prefs.K_DETAILED, false)) }
    var invert by remember { mutableStateOf(sp.getBoolean(Prefs.K_INVERT, false)) }
    var strength by remember { mutableFloatStateOf(sp.getFloat(Prefs.K_STRENGTH, 0.6f)) }
    var smooth by remember { mutableFloatStateOf(sp.getFloat(Prefs.K_SMOOTH, 0.5f)) }
    var focus by remember { mutableFloatStateOf(sp.getFloat(Prefs.K_FOCUS, 0.5f)) }
    var zoom by remember { mutableFloatStateOf(sp.getFloat(Prefs.K_ZOOM, 0.3f)) }

    fun setActive(id: String?) {
        active = id
        sp.edit().putString(Prefs.K_ACTIVE, id).apply()
    }

    fun addUris(uris: List<Uri>) {
        scope.launch {
            for ((i, u) in uris.withIndex()) {
                busy = "Calculating depth map ${i + 1}/${uris.size}…"
                val r = withContext(Dispatchers.Default) { runCatching { Store.add(ctx, u, detailed) } }
                r.onSuccess { (id, err) ->
                    ids = Store.ids(ctx)
                    setActive(id)
                    refresh++
                    if (err != null) toast(ctx, err)
                }.onFailure { toast(ctx, "Could not add image: ${it.message}") }
            }
            busy = null
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        if (uris.isNotEmpty()) addUris(uris)
    }
    fun pick() = picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))

    val preview by produceState<ImageBitmap?>(null, active, showDepth, refresh) {
        val id = active
        value = if (id == null) null else withContext(Dispatchers.IO) {
            val f = if (showDepth) Store.depth(ctx, id) else Store.image(ctx, id)
            if (!f.exists()) null else {
                val o = BitmapFactory.Options().apply { inSampleSize = if (showDepth) 1 else 2 }
                BitmapFactory.decodeFile(f.absolutePath, o)?.asImageBitmap()
            }
        }
    }

    val sheetHeight = (LocalConfiguration.current.screenHeightDp * 0.5f).dp

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize()) {
            // ---------- preview ----------
            Box(
                Modifier.weight(1f).fillMaxWidth().statusBarsPadding().padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.fillMaxHeight()
                        .aspectRatio(9f / 19.5f, matchHeightConstraintsFirst = true)
                        .clip(RoundedCornerShape(28.dp)).background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    val p = preview
                    if (p != null) {
                        Image(p, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Text("Tap + to add a wallpaper", color = Dim, fontSize = 14.sp)
                    }
                }
                Row(Modifier.align(Alignment.BottomStart), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill("‹") {
                        val i = ids.indexOf(active)
                        if (ids.isNotEmpty()) setActive(ids[(i - 1 + ids.size) % ids.size])
                    }
                    Pill("›") {
                        val i = ids.indexOf(active)
                        if (ids.isNotEmpty()) setActive(ids[(i + 1) % ids.size])
                    }
                }
                Box(Modifier.align(Alignment.BottomEnd)) {
                    Pill(if (showDepth) "Depth map" else "Wallpaper") { showDepth = !showDepth }
                }
            }

            // ---------- bottom sheet ----------
            Column(
                Modifier.fillMaxWidth().height(sheetHeight)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(Sheet).navigationBarsPadding().padding(top = 12.dp)
            ) {
                Row(
                    Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                        .clip(RoundedCornerShape(50)).background(CardC).padding(4.dp)
                ) {
                    listOf("Wallpapers", "Motion", "Setup").forEachIndexed { i, t ->
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(50))
                                .background(if (tab == i) Accent else Color.Transparent)
                                .clickable { tab = i }.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                t, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                                color = if (tab == i) Sheet else Accent
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))

                when (tab) {
                    0 -> LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Box(
                                Modifier.aspectRatio(9f / 16f).clip(RoundedCornerShape(16.dp))
                                    .background(CardC).clickable { pick() },
                                contentAlignment = Alignment.Center
                            ) { Text("+", fontSize = 36.sp, color = Accent) }
                        }
                        items(ids.reversed()) { id ->
                            Thumb(id, id == active, refresh,
                                onClick = { setActive(id) },
                                onDelete = {
                                    Store.delete(ctx, id)
                                    ids = Store.ids(ctx)
                                    if (active == id) setActive(ids.lastOrNull())
                                })
                        }
                    }

                    1 -> Column(
                        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Label("Parallax")
                        ToggleRow("Parallax Effect (Sensor)", "Moves the wallpaper when you tilt the phone", parallax) {
                            parallax = it; sp.edit().putBoolean(Prefs.K_PARALLAX, it).apply()
                        }
                        ToggleRow("Depth Parallax (AI)", "Uses the saved depth map. Off = flat shift", depthOn) {
                            depthOn = it; sp.edit().putBoolean(Prefs.K_DEPTH, it).apply()
                        }
                        ToggleRow("Detailed Depth Map", "Sharper depth, slower when adding an image", detailed) {
                            detailed = it; sp.edit().putBoolean(Prefs.K_DETAILED, it).apply()
                        }
                        ToggleRow("Invert Direction", "Flip the movement direction", invert) {
                            invert = it; sp.edit().putBoolean(Prefs.K_INVERT, it).apply()
                        }
                        SliderRow("Parallax Sensitivity", strength, "Subtle", "Strong") {
                            strength = it; sp.edit().putFloat(Prefs.K_STRENGTH, it).apply()
                        }
                        SliderRow("Smoothness", smooth, "Snappy", "Floaty") {
                            smooth = it; sp.edit().putFloat(Prefs.K_SMOOTH, it).apply()
                        }
                        SliderRow("Focus Point", focus, "Background", "Foreground") {
                            focus = it; sp.edit().putFloat(Prefs.K_FOCUS, it).apply()
                        }
                        SliderRow("Zoom (hides edges)", zoom, "Less", "More") {
                            zoom = it; sp.edit().putFloat(Prefs.K_ZOOM, it).apply()
                        }
                        Button(
                            onClick = {
                                val id = active ?: return@Button
                                scope.launch {
                                    busy = "Recalculating depth map…"
                                    val r = withContext(Dispatchers.Default) {
                                        runCatching { Store.recalc(ctx, id, detailed) }
                                    }
                                    r.onFailure { toast(ctx, "Depth failed: ${it.message}") }
                                    refresh++
                                    sp.edit().putInt(Prefs.K_REV, sp.getInt(Prefs.K_REV, 0) + 1).apply()
                                    busy = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = CardC, contentColor = Accent)
                        ) { Text("Recalculate Depth Map") }
                        Spacer(Modifier.height(16.dp))
                    }

                    else -> Column(
                        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Label("Apply")
                        Button(
                            onClick = {
                                val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                    ComponentName(ctx, ParallaxWallpaperService::class.java)
                                )
                                runCatching { ctx.startActivity(i) }.onFailure {
                                    ctx.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Set as Live Wallpaper") }
                        Text(
                            "In the preview, choose “Lock screen” (or both). " +
                                "Depth is calculated once when you add an image — the wallpaper itself " +
                                "never runs AI, so it stays light.",
                            color = Dim, fontSize = 13.sp
                        )
                        Label("Tips")
                        Text(
                            "• If the effect feels backwards, enable Invert Direction.\n" +
                                "• If you see edges, raise Zoom or lower Sensitivity.\n" +
                                "• After changing Detailed Depth Map, tap Recalculate Depth Map.",
                            color = Dim, fontSize = 13.sp
                        )
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }

        busy?.let { msg ->
            Box(
                Modifier.fillMaxSize().background(Color(0xCC000000)).clickable(enabled = false) {},
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Accent)
                    Spacer(Modifier.height(16.dp))
                    Text(msg, color = Accent)
                }
            }
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(Color(0xCC303036))
            .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 10.dp)
    ) { Text(text, color = Accent, fontWeight = FontWeight.Medium, fontSize = 15.sp) }
}

@Composable
private fun Label(t: String) =
    Text(t, color = Dim, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp))

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardC)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Accent, fontSize = 15.sp)
            Text(sub, color = Dim, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(title: String, value: Float, left: String, right: String, onChange: (Float) -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardC)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(title, color = Accent, fontSize = 15.sp)
        Slider(value = value, onValueChange = onChange)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(left, color = Dim, fontSize = 12.sp)
            Text(right, color = Dim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Thumb(id: String, selected: Boolean, refresh: Int, onClick: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, id, refresh) {
        value = withContext(Dispatchers.IO) {
            val o = BitmapFactory.Options().apply { inSampleSize = 6 }
            BitmapFactory.decodeFile(Store.image(ctx, id).absolutePath, o)?.asImageBitmap()
        }
    }
    Box(
        Modifier.aspectRatio(9f / 16f).clip(RoundedCornerShape(16.dp)).background(CardC)
            .clickable { onClick() }
    ) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (selected) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).clip(RoundedCornerShape(50))
                    .background(Color(0xCC000000)).clickable { onDelete() }
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            ) { Text("✕", color = Accent, fontSize = 12.sp) }
        }
    }
}
